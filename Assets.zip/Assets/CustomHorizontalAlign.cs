using UnityEngine;
using UnityEngine.UI;

namespace CustomNamespace
{
    [AddComponentMenu("Layout/Custom Horizontal Layout Group", 150)]
    /// <summary>
    /// Custom Layout class for arranging child elements side by side, preserving anchors.
    /// </summary>
    public class CustomHorizontalLayoutGroup : HorizontalOrVerticalLayoutGroup
    {
        protected CustomHorizontalLayoutGroup() {}

        public override void CalculateLayoutInputHorizontal()
        {
            // Here, we handle horizontal input calculation without affecting anchors.
            base.CalculateLayoutInputHorizontal();
            CalcAlongAxis(0, false);
        }

        public override void CalculateLayoutInputVertical()
        {
            // Here, we handle vertical input calculation, but it does not affect anchors.
            CalcAlongAxis(1, false);
        }

        public override void SetLayoutHorizontal()
        {
            // Set horizontal layout while preserving the anchors.
            SetChildrenAlongAxis(0, false);
        }

        public override void SetLayoutVertical()
        {
            // Set vertical layout, which generally affects child height but does not move the anchor.
            SetChildrenAlongAxis(1, false);
        }

        private void SetChildrenAlongAxis(int axis, bool isVertical)
        {
            // Calculate total width of children.
            float totalWidth = 0;
            for (int i = 0; i < rectChildren.Count; i++)
            {
                totalWidth += GetChildWidth(rectChildren[i]);
                if (i > 0) totalWidth += spacing; // Add spacing between elements
            }

            // Adjust positions of children.
            float x = 0;
            if (childAlignment == TextAnchor.MiddleCenter || childAlignment == TextAnchor.LowerCenter || childAlignment == TextAnchor.UpperCenter)
            {
                x = (rectTransform.rect.width - totalWidth) * 0.5f;
            }
            else if (childAlignment == TextAnchor.LowerRight || childAlignment == TextAnchor.MiddleRight || childAlignment == TextAnchor.UpperRight)
            {
                x = rectTransform.rect.width - totalWidth;
            }

            for (int i = 0; i < rectChildren.Count; i++)
            {
                var child = rectChildren[i];
                float childWidth = GetChildWidth(child);
                var childRect = child.rect;
                var childPivot = child.pivot;
                var childAnchoredPosition = child.anchoredPosition;

                child.anchoredPosition = new Vector2(x + childWidth * childPivot.x, child.anchoredPosition.y);
                x += childWidth + spacing;
            }
        }

        private float GetChildWidth(RectTransform child)
        {
            if (child == null) return 0;
            return child.rect.width;
        }
    }
}
