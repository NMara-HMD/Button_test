using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;

public class ButtonTextAnimator : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public RectTransform textTransform; // RectTransform тексту
    public float moveAmount = 10f; // Скільки текст рухатиметься вниз
    public float animationDuration = 0.2f; // Тривалість анімації

    private Vector3 originalPosition;
    private Vector3 targetPosition;

    private void Start()
    {
        originalPosition = textTransform.localPosition;
        targetPosition = originalPosition - new Vector3(0, moveAmount, 0);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        StartCoroutine(AnimateTextPosition(textTransform, originalPosition, targetPosition));
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        StartCoroutine(AnimateTextPosition(textTransform, targetPosition, originalPosition));
    }

    private IEnumerator AnimateTextPosition(RectTransform targetTransform, Vector3 startPosition, Vector3 endPosition)
    {
        float elapsedTime = 0f;

        while (elapsedTime < animationDuration)
        {
            elapsedTime += Time.deltaTime;
            float t = Mathf.Clamp01(elapsedTime / animationDuration);
            targetTransform.localPosition = Vector3.Lerp(startPosition, endPosition, t);
            yield return null;
        }

        targetTransform.localPosition = endPosition;
    }
}
